var socket = io();
var chamber = 6;

function shootPressed() {
	document.getElementById('overlay').style.display = 'block';
	socket.emit('passTurnRequest');
	socket.emit('disableShootButtonRequest');
	
	randomBulletChance();
}

function restartPressed() {
	socket.emit('restartPressedRequest');
}

function randomBulletChance() {
	//generate a random number between 0 an 100 and compare it with our real probability (16%) for each spin
	var bulletChance = Math.random()*100<(100/chamber);
	if(bulletChance) {
		socket.emit('bulletFoundRequest');		
	} else {
		socket.emit('flipGunRequest');
		document.getElementById('gun_spinner').style.display = 'block';	
	} 	
}

function checkDeadAlien(){
	var gunElem = document.getElementById('gun');
	var bgElem = document.getElementById('mainBg');
	if(gunElem.className == "gun gun-flip-R") {
		bgElem.classList.add("dead-R");
		bgElem.classList.remove("main-bg");
	} else {
		bgElem.classList.add("dead-L");
		bgElem.classList.remove("main-bg");
	}
}
	
function hideOverlay() {
	document.getElementById('overlay').style.display = 'none';
}

function flipGunToggle(id) {
    var elem = document.getElementById(id);
    if(elem.className == "gun") {
		elem.classList.add("gun-flip-R");
    } else {
        elem.classList.remove("gun-flip-R");
    }
}

// Received from server.js
socket.on('disableShootButton', function () {
	document.getElementById('shootBtn').disabled = true;
	document.getElementById('shootBtn').innerHTML = "WAIT...";
	document.getElementById('shootBtn').classList.add("disabled-button");
});

socket.on('enableShootButton', function () {
	document.getElementById('shootBtn').disabled = false;
	document.getElementById('shootBtn').innerHTML = "SHOOT";
	document.getElementById('shootBtn').classList.remove("disabled-button");
	hideOverlay();
});

socket.on('flipGun', function () {
	flipGunToggle('gun');
});

socket.on('restartPressedResponse', function () {
	document.getElementById('gameOver').classList.add("display-none");
	document.getElementById('shootBtn').classList.remove("display-none");
	document.getElementById('mainBg').classList.add("main-bg");
	document.getElementById('mainBg').classList.remove("dead-L", "dead-R");
	
	//document.getElementById('shootBtn').classList.remove("disabled-button");
	//document.getElementById('shootBtn').innerHTML = "SHOOT";
});

socket.on('bulletFound', function () {
	document.getElementById('gameOver').classList.remove("display-none");
	document.getElementById('shootBtn').classList.add("display-none");
	document.getElementById('result_label').innerHTML = "GAME OVER";
	hideOverlay();
	checkDeadAlien();
});