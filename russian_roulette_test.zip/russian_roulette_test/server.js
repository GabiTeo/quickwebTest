// Dependencies.
var express = require('express');
var http = require('http');
var path = require('path');
var socketIO = require('socket.io');

var app = express();
var server = http.Server(app);
var io = socketIO(server);

app.set('port', 5000);
app.use('/static', express.static(__dirname + '/static'));

// Routing
app.get('/', function(request, response) {
	response.sendFile(path.join(__dirname, 'index.html'));
});

server.listen(5000, function() {
	console.log('Starting server on port 5000');
});

var plrs = [];
var current_turn = 0;
var _turn = 0;

io.on('connection', function(socket) {
	
	// check clients number
	socket.join('test room');
	var clients = io.sockets.adapter.rooms['test room'];
	console.log(clients);
	for (var clientId in clients) {
		console.log(io.sockets.connected[clientId]);
	}

	plrs.push(socket);
	
	if(clients.length < 2) {
		socket.on('passTurnRequest',function(){
			if(plrs[_turn] == socket){
				//resetTimeOut();
				next_turn();
			}
		});
	} 
	
	// update gun flipping for all players including the emiter
	socket.on('flipGunRequest', function() {
		io.sockets.emit('flipGun');
	});
	
	socket.on('bulletFoundRequest', function() {
		io.sockets.emit('bulletFound');
	});
	
	socket.on('restartPressedRequest', function() {
		io.sockets.emit('restartPressedResponse');
	});
	
	socket.on('disableShootButtonRequest', function () {
		socket.emit('disableShootButton');
		socket.broadcast.emit('enableShootButton');
	});   		
	
});
   
function next_turn(){
	_turn = current_turn++ % plrs.length;
	console.log("plrs length", plrs.length);
	plrs[_turn].emit('your_turn');
	console.log("next turn triggered " , _turn);
}